Modules for (cavity-enhanced) linear spectroscopy.

# Installation
Install the package by downloading or cloning the repo and calling the following inside main repository directory (containing `setup.py`):

``` sh
python -m pip install --no-deps -e .
```

or by installing directly from the repo with pip

``` sh
python -m pip git+ssh://git@gitlab.com:allisonlab/mdcs/spectroscopy.git@master
```

