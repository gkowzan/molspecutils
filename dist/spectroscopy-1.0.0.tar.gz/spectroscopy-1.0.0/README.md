Modules for (cavity-enhanced) linear spectroscopy. 
